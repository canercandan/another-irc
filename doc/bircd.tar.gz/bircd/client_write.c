/*
** client_write.c for bircd in /u/guest/sb/c/bircd
** 
** Made by sebastien benoiT
** Login   <sb@epita.fr>
** 
** Started on  Tue Apr 17 09:02:44 2007 sebastien benoiT
** Last update Tue Apr 17 09:03:09 2007 sebastien benoiT
*/

#include "bircd.h"

void	client_write(t_env *e, int cs)
{
}
